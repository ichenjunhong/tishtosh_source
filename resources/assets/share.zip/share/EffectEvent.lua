local exports = exports or {}
local EffectEvent = EffectEvent or {}
EffectEvent.__index = EffectEvent

function EffectEvent.new(construct, ...)
    local self = setmetatable({}, EffectEvent)
    self.comps = {}
    if construct and EffectEvent.constructor then EffectEvent.constructor(self, ...) end
    return self
end

function EffectEvent:constructor()
end

function EffectEntry:onComponentAdded(sys, comp)
    if comp:isInstanceOf("EventActionCoupler") then
        print("comp.name:", comp.name)
        table.insert(self.comps, comp)
        self.compsdirty = true
    end
end

function EffectEntry:onComponentRemoved(sys, comp)
    local compCount = #self.comps
    for i = 1, compCount do
        if self.comps[i] == comp then
            table.remove(self.comps, i)
            self.compsdirty = true
        end
    end
end

function EffectEvent:onStart(sys)
    print("Can Test EffectEvent onStart ....")
    include("EffectRuntime")
    for i = 1, #self.comps do
        local entity = self.comps[i].entity
        --local scene = entity.scene
        local eventAction = entity:getComponent("EventActionCoupler")
        if(eventAction ~= nil) then

        end
        self.eventAction = eventAction

        self.luaScene = Runtime.LuaScene.new(true)
        self.luaScene:setEntity(entity)
    end
end

function EffectEvent:onUpdate(sys, deltaTime)

end

function EffectEvent:onEvent(sys, event)
    if (event.type == Amaz.EventType.EFFECT_COMPAT_EVENT) then -- event sdk algorithm event type
        local eventAction = self.eventAction
        local algorithm_res = event.args:get(0)
        local ev_type = algorithm_res.eventType
        
        if(ev_type == Amaz.BEFEventType.BET_USER)then
            if(algorithm_res.actionType == "boneAnimation") then
                local luaScene = self.luaScene
                local entityName = algorithm_res.entityName
                local action = algorithm_res.action
                local animName = algorithm_res.animClipName
                local isLoop = algorithm_res.isLoop
                if(action == "play")then
                    self.luaScene:play("BONE_ANIM", entityName, animName, isLoop)
                    self.eventAction.lastIsPlayAnimName = animName
                end
            end
        end
    end
end

exports.EffectEvent = EffectEvent
return exports
